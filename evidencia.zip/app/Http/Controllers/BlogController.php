<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BlogController extends Controller
{
    public function index()
    {
        $cards = [
            ['image' => 'images/html_y_css.jpg', 'title' => 'Introducción a HTML y CSS', 'text' => 'Descubre los conceptos básicos de HTML y CSS, los lenguajes fundamentales para construir sitios web.'],
            ['image' => 'images/php.jpg', 'title' => 'Introducción a PHP', 'text' => 'Aprende los fundamentos de PHP, uno de los lenguajes de programación más populares para el desarrollo web.'],
            ['image' => 'images/javascript.jpg', 'title' => 'Introducción a JavaScript', 'text' => 'Conoce JavaScript, el lenguaje que da vida a tus sitios web.'],
            ['image' => 'images/react.jpg', 'title' => 'Introducción a React', 'text' => 'Descubre React, una biblioteca de JavaScript para construir interfaces de usuario.'],
            ['image' => 'images/vue.jpg', 'title' => 'Introducción a Vue.js', 'text' => 'Aprende a crear aplicaciones interactivas con Vue.js, un framework progresivo para JavaScript.'],
        ];

        return view('home', compact('cards'));
    }

    public function posts()
    {
        return view('posts');
    }

    public function contact()
    {
        return view('contact');
    }

    public function blog()
    {
        return view('blog');
    }

    public function about()
    {
        return view('about');
    }
}

