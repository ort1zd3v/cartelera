<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
        <ul class="navbar-nav mx-auto">
            <li class="nav-item"><a class="nav-link" href="/">Inicio</a></li>
            <li class="nav-item"><a class="nav-link" href="/blog">Blog</a></li>
            <li class="nav-item"><a class="nav-link" href="/about">Sobre mí</a></li>
            <li class="nav-item"><a class="nav-link" href="/contact">Contacto</a></li>
        </ul>
    </div>
</nav>
