@extends('layouts.app')
@section('title', 'Inicio')
@section('header-title', 'Blog de Hazel Isaac Ortiz Jimenez')
@section('content')
    <h2>Bienvenido a mi blog personal</h2>
    <p>En este espacio comparto artículos sobre tecnología, desarrollo web y más. ¡Espero que disfrutes del contenido!</p>
    <section class="mt-5">
        <h3>Últimas publicaciones</h3>
        <div class="row">
            <div class="col-md-4">
                <div class="card">
                    <img src="assets/images/html_y_css.jpg" class="card-img-top" alt="HTML y CSS">
                    <div class="card-body">
                        <h5 class="card-title"><a href="/post">Introducción a HTML y CSS</a></h5>
                        <p class="card-text">Descubre los conceptos básicos de HTML y CSS, los lenguajes fundamentales para
                            construir sitios web.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
