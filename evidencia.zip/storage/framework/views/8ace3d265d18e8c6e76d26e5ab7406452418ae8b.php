<div id="carouselExample" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-inner">
        <?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="carousel-item <?php echo e($index === 0 ? 'active' : ''); ?>">
                <div class="row">
                    <div class="col-md-4">
                        <div class="card">
                            <img src="<?php echo e(asset($card['image'])); ?>" class="card-img-top" alt="<?php echo e($card['title']); ?>" />
                            <div class="card-body">
                                <h5 class="card-title">
                                    <a href="#"><?php echo e($card['title']); ?></a>
                                </h5>
                                <p class="card-text"><?php echo e($card['text']); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div>
<?php /**PATH C:\xampp\htdocs\Tecmi\evidencia\resources\views/components/carousel.blade.php ENDPATH**/ ?>