<header class="bg-dark text-white text-center py-4">
    <h1>Blog de Hazel Isaac Ortiz Jimenez</h1>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <ul class="navbar-nav mx-auto">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('home')); ?>">Inicio</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('blog')); ?>">Blog</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('about')); ?>">Sobre mí</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('contact')); ?>">Contacto</a>
                </li>
            </ul>
        </div>
    </nav>
</header>
<?php /**PATH C:\xampp\htdocs\Tecmi\evidencia\resources\views/components/header.blade.php ENDPATH**/ ?>